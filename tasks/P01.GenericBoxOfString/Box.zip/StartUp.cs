﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P01.GenericBoxOfString
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            var list = new List<Box<string>>();
            var box = new Box<string>("");
            for (int i = 0; i < n; i++)
            {
                var currentString = Console.ReadLine();
                 box = new Box<string>(currentString);
                list.Add(box);
                //Console.WriteLine(box);
            }
            var indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
            var index1 = indexes[0];
            var index2 = indexes[1];
            list = box.SwapElements(list, index1, index2).ToList();
            Console.WriteLine(String.Join(Environment.NewLine, list));
        }
    }
}
